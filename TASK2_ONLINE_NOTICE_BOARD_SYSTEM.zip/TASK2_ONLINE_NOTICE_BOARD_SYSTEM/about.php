<h2><b>ABOUT US</b></h2>
<h3>This Online Notice Board System is build for communication with the college updates!!</h3>
